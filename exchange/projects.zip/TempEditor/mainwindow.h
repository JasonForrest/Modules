#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QHeaderView>
#include <QItemDelegate>
#include <QStandardItemModel>
#include <pugixml.hpp>
#include <QFile>

namespace Ui {
class MainWindow;
}

class GameField : public QTableWidget
{
    Q_OBJECT

public:
    enum FieldAlign
    {
        Horisontal = 0,
        Vertical,
        Both
    };

    GameField(int fieldsCount, QSize screenSize,
              int cellSize = 20,
              FieldAlign fieldAlign = Horisontal,
              QWidget *parent = NULL)
        : QTableWidget(parent)
        , _fieldsCount(fieldsCount)
        , _cellSize(cellSize)
        , _screenSize(screenSize)
        , _fieldAlign(fieldAlign)
        , _currentColor(Qt::white)
    {
        horizontalHeader()->setVisible(true);
        verticalHeader()->setVisible(true);

        horizontalHeader()->setEnabled(false);
        verticalHeader()->setEnabled(false);

        _fieldSize = QSize(_screenSize.width() / _cellSize, _screenSize.height() / _cellSize);

        int columnsSummaryCount = 0;
        int rowsSummaryCount = 0;

        if (_fieldAlign == Horisontal)
        {
            columnsSummaryCount = _fieldSize.width() * _fieldsCount;
            rowsSummaryCount = _fieldSize.height();
        }
        else if (_fieldAlign == Vertical)
        {
            columnsSummaryCount = _fieldSize.width();
            rowsSummaryCount = _fieldSize.height() * _fieldsCount;
        }
        else
        {
            columnsSummaryCount = _fieldSize.width() * _fieldsCount;
            rowsSummaryCount = _fieldSize.height() * _fieldsCount;
        }

        setColumnCount(_fieldSize.width() * _fieldsCount);
        setRowCount(rowsSummaryCount);

        for (int i = 0; i < columnsSummaryCount; i++)
        {
            setColumnWidth(i, _cellSize);
        }

        for (int i = 0; i < rowsSummaryCount; i++)
        {
            setRowHeight(i, _cellSize);
        }

        if (!loadProject())
        {
            for (int i = 0; i < columnsSummaryCount; i++)
            {
                for (int j = 0; j < rowsSummaryCount; j++)
                {
                    QTableWidgetItem *itm = new QTableWidgetItem();
                    itm->setBackgroundColor(QColor("white"));
                    setItem(j, i, itm);
                }
            }
        }

        setSelectionMode(QAbstractItemView::NoSelection);
        connect(this, SIGNAL(cellEntered(int,int)), this, SLOT(setCellColor(int, int)));
        connect(this, SIGNAL(cellPressed(int,int)), this, SLOT(setCellColor(int, int)));
    }

    ~GameField()
    {

    }

    void setNewColor(QColor color)
    {
        _currentColor = color;
    }

    void clearField()
    {
        for (int i = 0; i < rowCount(); i++)
        {
            for (int j = 0; j < columnCount(); j++)
            {
                item(i, j)->setBackgroundColor(QColor("white"));
            }
        }
    }

public Q_SLOTS:
    void setCellColor(int row, int col)
    {
        item(row, col)->setBackgroundColor(_currentColor);
    }

    void saveProject()
    {
        _settingsDocument.reset();
        pugi::xml_node root = _settingsDocument.append_child("GameField");

        for (int i = 0; i < rowCount(); i++)
        {
            for (int j = 0; j < columnCount(); j++)
            {
                QColor color = item(i, j)->backgroundColor();

                pugi::xml_node item_node = root.append_child("item");
                pugi::xml_attribute attribute_row = item_node.append_attribute("row");
                attribute_row.set_value(i);
                pugi::xml_attribute attribute_col = item_node.append_attribute("col");
                attribute_col.set_value(j);
                pugi::xml_attribute attribute_color = item_node.append_attribute("color");
                attribute_color.set_value(color.name().toStdString().c_str());
            }
        }

        _settingsDocument.save_file("gamemap.xml");
    }

    bool loadProject()
    {
        _parseResult = _settingsDocument.load_file("gamemap.xml");

        if (_parseResult)
        {
            pugi::xml_node items = _settingsDocument.child("GameField");

            for (pugi::xml_node item = items.first_child(); item; item = item.next_sibling())
            {
                int row = item.attribute("row").as_int();
                int col = item.attribute("col").as_int();
                std::string color = item.attribute("color").as_string();

                QTableWidgetItem *itm = new QTableWidgetItem();
                itm->setBackgroundColor(QColor(color.c_str()));
                setItem(row, col, itm);
            }
        }
        else
        {
            return false;
        }

        return true;
    }

private:
    int _fieldsCount;
    int _cellSize;
    QSize _fieldSize;
    QSize _screenSize;
    FieldAlign _fieldAlign;

    QColor _currentColor;
    pugi::xml_document _settingsDocument;
    pugi::xml_parse_result _parseResult;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public Q_SLOTS:
    void setNewColor(int index);
    void clearField();

private:
    void closeEvent(QCloseEvent *cevent);
    
private:
    Ui::MainWindow *ui;
    GameField *_gameField;
};

#endif // MAINWINDOW_H
