#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRadioButton>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    _gameField = new GameField(3, QSize(800, 600));

    ui->gridLayout->addWidget(_gameField, 0,0,1,1);

    ui->comboBox->addItem(QString("None"), QVariant(QString("white")));
    ui->comboBox->addItem(QString("Start point"), QVariant(QString("red")));
    ui->comboBox->addItem(QString("End point"), QVariant(QString("black")));
    ui->comboBox->addItem(QString("Path"), QVariant(QString("yellow")));
    ui->comboBox->addItem(QString("Battle tower"), QVariant(QString("magenta")));
    ui->comboBox->addItem(QString("Bounds"), QVariant(QString("blue")));
    ui->comboBox->addItem(QString("Build area"), QVariant(QString("green")));

    ui->comboBox->setCurrentIndex(0);
    _gameField->setNewColor(QColor(ui->comboBox->itemData(0).toString()));

    connect(ui->comboBox, SIGNAL(activated(int)), this, SLOT(setNewColor(int)));
    connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(clearField()));
}

void MainWindow::setNewColor(int index)
{
    QString color = ui->comboBox->itemData(index).toString();
    _gameField->setNewColor(QColor(color));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *cevent)
{
    _gameField->saveProject();
    QMainWindow::closeEvent(cevent);
}

void MainWindow::clearField()
{
    _gameField->clearField();
}
