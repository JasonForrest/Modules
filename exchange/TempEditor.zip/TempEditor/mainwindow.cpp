#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRadioButton>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    _gameField = new GameField;
    ui->gridLayout->addWidget(_gameField, 0,0,1,1);

    ui->comboBoxAreaColor->addItem(QString("None"), QVariant(QString("white")));
    ui->comboBoxAreaColor->addItem(QString("Start point"), QVariant(QString("red")));
    ui->comboBoxAreaColor->addItem(QString("End point"), QVariant(QString("black")));
    ui->comboBoxAreaColor->addItem(QString("Path"), QVariant(QString("yellow")));
    ui->comboBoxAreaColor->addItem(QString("Battle tower"), QVariant(QString("magenta")));
    ui->comboBoxAreaColor->addItem(QString("Bounds"), QVariant(QString("blue")));
    ui->comboBoxAreaColor->addItem(QString("Build area"), QVariant(QString("green")));

    connect(ui->actionLoad, SIGNAL(triggered()), this, SLOT(loadProject()));
    connect(ui->actionSave, SIGNAL(triggered()), this, SLOT(saveProject()));

    connect(ui->comboBoxAreaColor, SIGNAL(activated(int)), this, SLOT(setNewColor(int)));
    connect(ui->pushButtonClearField, SIGNAL(clicked()), this, SLOT(clearField()));

    connect(ui->pushButtonCreateField, SIGNAL(clicked()), this, SLOT(createField()));
    connect(ui->pushButtonRemoveField, SIGNAL(clicked()), this, SLOT(removeField()));

    refreshParametersFields();
}

void MainWindow::setNewColor(int index)
{
    QString color = ui->comboBoxAreaColor->itemData(index).toString();
    _gameField->setNewColor(QColor(color));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::refreshParametersFields()
{
    ui->spinBoxFieldCellSize->setValue(20);
    ui->spinBoxFieldsCount->setValue(2);
    ui->spinBoxOnePlayerFieldHeight->setValue(ui->spinBoxOnePlayerFieldHeight->minimum());
    ui->spinBoxOnePlayerFieldWidth->setValue(ui->spinBoxOnePlayerFieldWidth->minimum());

    ui->lineEditOnePlayerFieldSizeRow->setText("");
    ui->lineEditOnePlayerFieldSizeCol->setText("");
    ui->lineEditAllFieldSizeRow->setText("");
    ui->lineEditAllFieldSizeCol->setText("");
    ui->lineEditFieldSizeWidth->setText("");
    ui->lineEditFieldSizeHeight->setText("");

    ui->comboBoxAreaColor->setCurrentIndex(0);
    _gameField->setNewColor(QColor(ui->comboBoxAreaColor->itemData(0).toString()));
}

void MainWindow::fillCurrentGameFieldParameters()
{
    ui->lineEditOnePlayerFieldSizeRow->setText(QString("%1").arg(_gameField->getFieldSize().width()));
    ui->lineEditOnePlayerFieldSizeCol->setText(QString("%1").arg(_gameField->getFieldSize().height()));
    ui->lineEditAllFieldSizeRow->setText(QString("%1").arg(_gameField->getAllFieldSizeCell().width()));
    ui->lineEditAllFieldSizeCol->setText(QString("%1").arg(_gameField->getAllFieldSizeCell().height()));
    ui->lineEditFieldSizeWidth->setText(QString("%1").arg(_gameField->getAllFieldSizePx().width()));
    ui->lineEditFieldSizeHeight->setText(QString("%1").arg(_gameField->getAllFieldSizePx().height()));
}

void MainWindow::loadProject()
{
    removeField();
    _gameField->loadProject();
    enableGroupBoxFieldCreateParameters(false);
}

void MainWindow::saveProject()
{
    _gameField->saveProject();
}

void MainWindow::closeEvent(QCloseEvent *cevent)
{
    QMainWindow::closeEvent(cevent);
}

void MainWindow::createField()
{
    _gameField->initGameField(ui->spinBoxFieldsCount->value(),
                              QSize(ui->spinBoxOnePlayerFieldWidth->value(), ui->spinBoxOnePlayerFieldHeight->value()),
                              ui->spinBoxFieldCellSize->value());

    enableGroupBoxFieldCreateParameters(false);
    fillCurrentGameFieldParameters();
}

void MainWindow::removeField()
{
    _gameField->removeField();

    refreshParametersFields();
    enableGroupBoxFieldCreateParameters(true);
}

void MainWindow::clearField()
{
    _gameField->clearField();
}

void MainWindow::enableGroupBoxFieldCreateParameters(bool const& enable)
{
    ui->groupBoxFieldCreateParameters->setEnabled(enable);
}
