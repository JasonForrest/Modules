#ifndef GAMEFIELD_H
#define GAMEFIELD_H

#include <QTableWidget>
#include <QHeaderView>
#include <QItemDelegate>
#include <QStandardItemModel>
#include <QFile>
#include <pugixml.hpp>

class GameField : public QTableWidget
{
    Q_OBJECT

public:
    enum FieldAlign
    {
        Horisontal = 0,
        Vertical,
        Both
    };

    GameField(QWidget *parent = NULL);
    ~GameField();

    void initGameField(int fieldsCount, QSize screenSize, int cellSize = 20, FieldAlign fieldAlign = Horisontal);
    void clearField();
    void removeField();

    //setters
    inline void setNewColor(QColor const& color)
    {
        _currentColor = color;
    }

    inline void setFieldsCount(int const& count)
    {
        _fieldsCount = count;
    }

    inline void setCellSize(int const& size)
    {
        _cellSize = size;
    }

    inline void setFieldSize(QSize const& fieldSize)
    {
        _fieldSize = fieldSize;
    }

    //getters
    inline int const& getFieldsCount()
    {
        return _fieldsCount;
    }

    inline int const& getCellSize()
    {
        return _cellSize;
    }

    inline QSize const& getFieldSize()
    {
        return _fieldSize;
    }

    inline QSize const& getScreenSize()
    {
        return _screenSize;
    }

    inline QSize const& getAllFieldSizePx()
    {
        return _allFieldSizePx;
    }

    inline QSize const& getAllFieldSizeCell()
    {
        return _allFieldSizeCell;
    }

    inline FieldAlign const& getFieldAlign()
    {
        return _fieldAlign;
    }

    inline QColor const& getCurrentColor()
    {
        return _currentColor;
    }

public Q_SLOTS:
    void setCellColor(int row, int col);
    void saveProject();
    bool loadProject();

private:
    int _fieldsCount; //same as player count
    int _cellSize; //in pixels width x height
    QSize _fieldSize; //in cells row x col
    QSize _screenSize; //in pixels (for one player)
    QSize _allFieldSizePx; //in pixels width x height
    QSize _allFieldSizeCell; //in pixels row x col
    FieldAlign _fieldAlign;

    QColor _currentColor;
    pugi::xml_document _settingsDocument;
    pugi::xml_parse_result _parseResult;
};

#endif // GAMEFIELD_H
