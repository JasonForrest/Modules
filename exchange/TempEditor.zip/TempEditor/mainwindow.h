#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "gamefield.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void refreshParametersFields();
    void fillCurrentGameFieldParameters();

public Q_SLOTS:
    void setNewColor(int index);
    void clearField();
    void removeField();
    void createField();
    void loadProject();
    void saveProject();

private:
    void enableGroupBoxFieldCreateParameters(bool const& enable);

private:
    void closeEvent(QCloseEvent *cevent);
    
private:
    Ui::MainWindow *ui;
    GameField *_gameField;
};

#endif // MAINWINDOW_H
