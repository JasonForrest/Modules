#include "gamefield.h"

GameField::GameField(QWidget *parent)
    : QTableWidget(parent)
    , _fieldsCount(1)
    , _cellSize(20)
    , _screenSize(QSize(800, 600))
    , _fieldAlign(Horisontal)
    , _currentColor(Qt::white)
    , _allFieldSizePx(QSize(800, 600))
    , _allFieldSizeCell(QSize(40, 30))
    , _fieldSize(QSize(40, 30))
{
    horizontalHeader()->setVisible(true);
    verticalHeader()->setVisible(true);

    horizontalHeader()->setEnabled(false);
    verticalHeader()->setEnabled(false);

    connect(this, SIGNAL(cellEntered(int,int)), this, SLOT(setCellColor(int, int)));
    connect(this, SIGNAL(cellPressed(int,int)), this, SLOT(setCellColor(int, int)));
}

GameField::~GameField()
{
    removeField();
}

void GameField::initGameField(int fieldsCount, QSize screenSize, int cellSize, FieldAlign fieldAlign)
{
    _fieldsCount = fieldsCount;
    _screenSize = screenSize;
    _cellSize = cellSize;
    _fieldAlign = fieldAlign;

    _fieldSize = QSize(_screenSize.width() / _cellSize, _screenSize.height() / _cellSize);

    int columnsSummaryCount = 0;
    int rowsSummaryCount = 0;

    if (_fieldAlign == Horisontal)
    {
        columnsSummaryCount = _fieldSize.width() * _fieldsCount;
        rowsSummaryCount = _fieldSize.height();

        _allFieldSizePx = QSize(_screenSize.width() * _fieldsCount, _screenSize.height());
    }
    else if (_fieldAlign == Vertical)
    {
        columnsSummaryCount = _fieldSize.width();
        rowsSummaryCount = _fieldSize.height() * _fieldsCount;

        _allFieldSizePx = QSize(_screenSize.width(), _screenSize.height() * _fieldsCount);
    }
    else
    {
        columnsSummaryCount = _fieldSize.width() * _fieldsCount;
        rowsSummaryCount = _fieldSize.height() * _fieldsCount;

        _allFieldSizePx = QSize(_screenSize.width() * _fieldsCount, _screenSize.height() * _fieldsCount);
    }

    setColumnCount(columnsSummaryCount);
    setRowCount(rowsSummaryCount);

    _allFieldSizeCell = QSize(columnsSummaryCount, rowsSummaryCount);

    for (int i = 0; i < columnsSummaryCount; i++)
    {
        setColumnWidth(i, _cellSize);
    }

    for (int i = 0; i < rowsSummaryCount; i++)
    {
        setRowHeight(i, _cellSize);
    }

    for (int i = 0; i < rowsSummaryCount; i++)
    {
        for (int j = 0; j < columnsSummaryCount; j++)
        {
            QTableWidgetItem *itm = new QTableWidgetItem();
            itm->setBackgroundColor(QColor("white"));
            setItem(i, j, itm);
        }
    }

    setSelectionMode(QAbstractItemView::NoSelection);
}

void GameField::removeField()
{
    clear();
    setColumnCount(0);
    setRowCount(0);
}

void GameField::clearField()
{
    for (int i = 0; i < _allFieldSizeCell.height(); i++)
    {
        for (int j = 0; j < _allFieldSizeCell.width(); j++)
        {
            item(i, j)->setBackgroundColor(QColor("white"));
        }
    }
}

void GameField::setCellColor(int row, int col)
{
    item(row, col)->setBackgroundColor(_currentColor);
}

void GameField::saveProject()
{
    _settingsDocument.reset();

    pugi::xml_node root = _settingsDocument.append_child("GameField");
    pugi::xml_attribute fieldsCount = root.append_attribute("FieldsCount");
    pugi::xml_attribute screenSizeWidth = root.append_attribute("ScreenSizeWidth");
    pugi::xml_attribute screenSizeHeight = root.append_attribute("ScreenSizeHeight");
    pugi::xml_attribute cellSize = root.append_attribute("CellSize");
    pugi::xml_attribute fieldAlign = root.append_attribute("FieldAlign");

    fieldsCount.set_value(_fieldsCount);
    screenSizeWidth.set_value(_screenSize.width());
    screenSizeHeight.set_value(_screenSize.height());
    cellSize.set_value(_cellSize);
    fieldAlign.set_value(_fieldAlign);

    for (int i = 0; i < _allFieldSizeCell.height(); i++)
    {
        for (int j = 0; j < _allFieldSizeCell.width(); j++)
        {
            QColor color = item(i, j)->backgroundColor();

            pugi::xml_node item_node = root.append_child("item");
            pugi::xml_attribute attribute_row = item_node.append_attribute("row");
            attribute_row.set_value(i);
            pugi::xml_attribute attribute_col = item_node.append_attribute("col");
            attribute_col.set_value(j);
            pugi::xml_attribute attribute_color = item_node.append_attribute("color");
            attribute_color.set_value(color.name().toStdString().c_str());
        }
    }

    _settingsDocument.save_file("gamemap.xml");
}

bool GameField::loadProject()
{
    _settingsDocument.reset();

    _parseResult = _settingsDocument.load_file("gamemap.xml");

    pugi::xml_node root = _settingsDocument.child("GameField");
    int fieldsCount = root.attribute("FieldsCount").as_int();
    QSize screenSize = QSize(root.attribute("ScreenSizeWidth").as_int(), root.attribute("ScreenSizeHeight").as_int());
    int cellSize = root.attribute("CellSize").as_int();
    FieldAlign fieldAlign = (FieldAlign)root.attribute("FieldAlign").as_int();

    initGameField(fieldsCount, screenSize, cellSize, fieldAlign);

    if (_parseResult)
    {
        pugi::xml_node cells = _settingsDocument.child("GameField");

        for (pugi::xml_node cell = cells.first_child(); cell; cell = cell.next_sibling())
        {
            int row = cell.attribute("row").as_int();
            int col = cell.attribute("col").as_int();
            std::string color = cell.attribute("color").as_string();

            this->item(row, col)->setBackgroundColor(QColor(color.c_str()));;
        }
    }
    else
    {
        return false;
    }

    return true;
}
